<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-03 05:36:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-1' at line 1 - Invalid query: SELECT * FROM tbl_booking WHERE isDeleted = '0'  ORDER BY bookingId ASC  LIMIT 0, -1
ERROR - 2024-05-03 17:32:16 --> Severity: error --> Exception: syntax error, unexpected token "public" /home/kqtvoass/jinpushpinfotech.in/calling/application/controllers/Task.php 207
